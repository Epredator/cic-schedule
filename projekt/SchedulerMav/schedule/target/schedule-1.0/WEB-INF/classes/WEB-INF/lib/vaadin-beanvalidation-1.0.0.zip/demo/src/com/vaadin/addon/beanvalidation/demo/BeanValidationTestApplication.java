package com.vaadin.addon.beanvalidation.demo;

import com.vaadin.Application;
import com.vaadin.addon.beanvalidation.BeanValidationForm;
import com.vaadin.data.Item;
import com.vaadin.data.Validator.InvalidValueException;
import com.vaadin.data.util.BeanItem;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Component;
import com.vaadin.ui.DefaultFieldFactory;
import com.vaadin.ui.Field;
import com.vaadin.ui.TextField;
import com.vaadin.ui.Window;
import com.vaadin.ui.Window.Notification;

/**
 * Bean Validation test and sample application.
 */
@SuppressWarnings("serial")
public class BeanValidationTestApplication extends Application
{
    private Window window;

    @Override
    public void init()
    {
        window = new Window("Bean Validation Test");

        BeanToValidate bean = new BeanToValidate();

        final BeanValidationForm<BeanToValidate> form = new BeanValidationForm<BeanToValidate>(
                BeanToValidate.class);

        // show null values as empty strings
        form.setFormFieldFactory(new DefaultFieldFactory() {
            @Override
            public Field createField(Item item, Object propertyId,
                    Component uiContext) {
                Field field = super.createField(item, propertyId, uiContext);
                if (field instanceof TextField) {
                    ((TextField) field).setNullRepresentation("");
                }
                return field;
            }
        });

        // use a BeanItem<BeanToValidate> for full validation
        form.setItemDataSource(new BeanItem<BeanToValidate>(bean));

        // validate immediately when field focus lost but use explicit commit
        form.setImmediate(true);
        form.setWriteThrough(false);

        window.addComponent(form);

        // explicit validation button
        Button validate = new Button("Validate");
        validate.addListener(new Button.ClickListener() {
            public void buttonClick(ClickEvent event) {
                try {
                    form.validate();
                    window.showNotification("Validation successful");
                } catch (InvalidValueException e) {
                    window.showNotification(
                            "Validation failed: " + e.getMessage(),
                            Notification.TYPE_WARNING_MESSAGE);
                }
            }
        });
        window.addComponent(validate);

        setMainWindow(window);
    }
    
}
